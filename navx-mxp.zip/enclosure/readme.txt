This directory contains the following files:

navx-mxp.skp:  Sketchup File for the navX MXP Circuit Board
navx-mxp.3ds:  3D-Studio File for the navX MXP Circuit Board
navx-mxp.stp:  STEP File for the navx MXP Circuit Board
navXLogo.skp:  Sketchup File for the navX MXP Logo
navx-mxp-roborio-lid_v4.skp:  Sketchup File for the navX MXP Roborio Lid-style enclosure (X1000 scale)
navx-mxp-roborio-lid_v4.stp:  STEP File for the navX MXP Roborio Lid-style enclosure (X1000 scale)
navx-mxp-roborio-lid_v4.stl:  STL File for the navX MXP Roborio Lid-style enclosure (X1000 scale)
navx-mxp-roborio-lid_v4.3ds:  3D-Studio File for the navX MXP Roborio Lid-style enclosure (X1000 scale)
navx-mxp-roborio-lid_v4_scaleddown.skp:  Sketchup File for the navX MXP Roborio Lid-style enclosure
navx-mxp-roborio-lid_v4_scaleddown.stp:  STEP File for the navX MXP Roborio Lid-style enclosure
navx-mxp-roborio-lid_v4_scaleddown.stl:  STL File for the navX MXP Roborio Lid-style enclosure
navx-mxp-roborio-lid_v4_scaleddown.3ds:  3D-Studio File for the navX MXP Roborio Lid-style enclosure
